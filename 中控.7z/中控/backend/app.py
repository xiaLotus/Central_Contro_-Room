import json
from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
import os
from loguru import logger
from routes.auth import auth_bp  
from routes.websites import websites_bp
from utils.config import config 

def create_app():
    app = Flask(__name__)
    
    # ✅ 設定 CORS（允許前端跨域請求）
    CORS(app, resources={
        r"/api/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type"]
        }
    })

    # === Loguru Logger 設定 ===
    log_file = config.get_path('Paths', 'log_file')
    log_dir = os.path.dirname(log_file) # type: ignore
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    # 配置 loguru
    logger.add(
        log_file, # type: ignore
        rotation="10 MB",
        retention="30 days",
        compression="zip",
        encoding="utf-8",
        format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} - {message}"
    )

    logger.info("🚀 FT01 資訊管理組系統啟動")

    # ✅ 註冊藍圖
    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(websites_bp, url_prefix="/api")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)



    
    # @app.route("/api/websites")
    # def get_websites():
    #     # 從 json 檔讀資料
    #     json_path = os.path.join(os.path.dirname(__file__), "websites.json")
    #     with open(json_path, "r", encoding="utf-8-sig") as f:
    #         data = json.load(f)
    #     return jsonify(data)
