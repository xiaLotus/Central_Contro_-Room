"""
主應用程式 - 完整版
放置位置: app.py
"""

import json
from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
import os
from loguru import logger
from routes.auth import auth_bp  
from routes.websites import websites_bp
from utils.config import config
from utils.session_manager import start_cleanup_task  # ← 新增
import logging

def create_app():
    app = Flask(__name__)
    
    # 設定 CORS
    CORS(app, resources={
        r"/api/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type"]
        }
    })

    # Logger 設定
    log_file = config.get_path('Paths', 'log_file')
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
        
    logger_instance = logging.getLogger()
    logger_instance.setLevel(logging.INFO)

    if not logger_instance.handlers:
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )

        # 檔案輸出
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger_instance.addHandler(file_handler)

        # Console 輸出
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger_instance.addHandler(console_handler)
    
    logger_instance.info("🚀 FT01 資訊管理組系統啟動")
        
    # 註冊藍圖
    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(websites_bp, url_prefix="/api")
    
    # ✅ 啟動定期清理過期會話
    start_cleanup_task(app)
    logger_instance.info("✅ 會話管理系統已啟動")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)

    
    # @app.route("/api/websites")
    # def get_websites():
    #     # 從 json 檔讀資料
    #     json_path = os.path.join(os.path.dirname(__file__), "websites.json")
    #     with open(json_path, "r", encoding="utf-8-sig") as f:
    #         data = json.load(f)
    #     return jsonify(data)
