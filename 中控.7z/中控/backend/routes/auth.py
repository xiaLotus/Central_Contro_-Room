import json
import os
from flask import Blueprint, request, jsonify
from utils.auth import authenticate_user
from loguru import logger

auth_bp = Blueprint("auth_bp", __name__)

@auth_bp.route("/login", methods=["POST"])
def login():
    try:
        data = request.get_json()
        username = data.get("username", "").strip()
        password = data.get("password", "").strip()

        if not username or not password:
            return jsonify({"success": False, "message": "請輸入帳號與密碼"}), 400

        # 1️⃣ 讀取 emoinfo.json（員工資訊）
        emoinfo_path = os.path.join("static", "emoinfo.json")
        if not os.path.exists(emoinfo_path):
            return jsonify({"success": False, "message": "找不到 emoinfo.json"}), 500

        try:
            with open(emoinfo_path, "r", encoding="utf-8-sig") as f:
                emoinfo = json.load(f)
        except Exception as e:
            return jsonify({"success": False, "message": f"員工名單載入失敗: {str(e)}"}), 500

        # 檢查工號是否存在
        matched_user = next((item for item in emoinfo if item["工號"] == username), None)
        if not matched_user:
            return jsonify({"success": False, "message": "您不在允許登入名單中"}), 403

        # 2️⃣ 呼叫 LDAP 驗證（目前為測試模式）
        if not authenticate_user(username, password):
            return jsonify({"success": False, "message": "帳號或密碼錯誤"}), 401

        # 3️⃣ 讀取管理員名單 admin_list.json
        admin_path = os.path.join("static", "admin_list.json")
        admin_list = []
        
        if os.path.exists(admin_path):
            try:
                with open(admin_path, "r", encoding="utf-8-sig") as f:
                    admin_data = json.load(f)
                    admin_list = admin_data.get("管理員", [])
            except Exception as e:
                logger.info(f"⚠️ 管理員名單載入失敗: {str(e)}")

        # 4️⃣ 讀取編輯者名單 editor_list.json
        editor_path = os.path.join("static", "editor_list.json")
        editor_list = []
        
        if os.path.exists(editor_path):
            try:
                with open(editor_path, "r", encoding="utf-8-sig") as f:
                    editor_data = json.load(f)
                    editor_list = editor_data.get("編輯者", [])
            except Exception as e:
                logger.info(f"⚠️ 編輯者名單載入失敗: {str(e)}")

        # 5️⃣ 判斷權限（優先級：管理員 > 編輯者 > 使用者）
        is_admin = username in admin_list
        is_editor = username in editor_list
        
        if is_admin:
            role = "管理員"
        elif is_editor:
            role = "編輯者"
        else:
            role = "使用者"

        # ✅ 測試模式
        logger.info(f"{username} 成功登入，身分 {role}")

        # ✅ 成功登入，回傳角色資訊
        return jsonify({
            "success": True,
            "message": "登入成功",
            "工號": matched_user["工號"],
            "姓名": matched_user["姓名"],
            "chataster": role  # 前端使用此欄位
        })

    except Exception as e:
        return jsonify({"success": False, "message": f"伺服器錯誤: {str(e)}"}), 500