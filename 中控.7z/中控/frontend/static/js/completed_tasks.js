const app = Vue.createApp({
  // ==================== 數據 ====================
  data() {
    return {
      websiteData: null,
      loading: true,
      currentTime: new Date(),
      timer: null,
      userId: '',
      username: '',
      role: '',
      isDarkMode: false,
      showTaskModal: false,
      isEditMode: false,
      currentTask: {
        title: '',
        description: '',
        completedDate: '',
        completedBy: ''
      },
      editingIndex: null
    };
  },

  // ==================== 計算屬性 ====================
  computed: {
    isEditor() {
      return this.role === '編輯者';
    },
    
    completedTasksCount() {
      if (!this.websiteData || !this.websiteData.completedTasks) return 0;
      return Array.isArray(this.websiteData.completedTasks) 
        ? this.websiteData.completedTasks.length 
        : 0;
    }
  },

  // ==================== 監聽器 ====================
  watch: {
    showTaskModal(newVal) {
      this.$nextTick(() => {
        if (typeof lucide !== 'undefined') {
          lucide.createIcons();
        }
      });
    }
  },

  // ==================== 生命週期鉤子 ====================
  mounted() {
    // ✅ 檢查登入狀態
    const loginUsername = localStorage.getItem("username") || localStorage.getItem("工號");
    if (!loginUsername) {
      console.warn('⚠️ 未登入，導向登入頁面');
      window.location.href = '../login.html';
      return;
    }
    
    this.userId = loginUsername;  // 工號，用於 API 請求
    this.username = localStorage.getItem('姓名') || '訪客';  // 姓名，用於顯示
    this.role = localStorage.getItem('role') || localStorage.getItem('chataster') || '使用者';
    
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode !== null) {
      this.isDarkMode = savedDarkMode === 'true';
      this.applyDarkMode(this.isDarkMode);
    }
    
    this.loadWebsiteData();
    
    this.timer = setInterval(() => {
      this.currentTime = new Date();
    }, 1000);
    
    this.$nextTick(() => {
      if (typeof lucide !== 'undefined') {
        lucide.createIcons();
      }
    });
  },

  updated() {
    this.$nextTick(() => {
      if (typeof lucide !== 'undefined') {
        lucide.createIcons();
      }
    });
  },

  beforeUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  },

  // ==================== 方法 ====================
  methods: {
    // -------------------- 暗色模式 --------------------
    applyDarkMode(isDark) {
      if (isDark) {
        document.documentElement.classList.add('dark');
        document.body.classList.remove('bg-gradient-to-br', 'from-green-50', 'via-emerald-50', 'to-teal-50');
        document.body.classList.add('dark-mode-bg');
      } else {
        document.documentElement.classList.remove('dark');
        document.body.classList.remove('dark-mode-bg');
        document.body.classList.add('bg-gradient-to-br', 'from-green-50', 'via-emerald-50', 'to-teal-50');
      }
    },

    toggleDarkMode() {
      this.isDarkMode = !this.isDarkMode;
      localStorage.setItem('darkMode', this.isDarkMode.toString());
      this.applyDarkMode(this.isDarkMode);
      this.$nextTick(() => {
        if (typeof lucide !== 'undefined') {
          lucide.createIcons();
        }
      });
    },

    // -------------------- 樣式相關 --------------------
    getRoleBadgeClass() {
      const roles = {
        '管理員': this.isDarkMode ? 'bg-purple-900/50 text-purple-300 border-purple-700/50' : 'bg-purple-100 text-purple-700 border-purple-200',
        '編輯者': this.isDarkMode ? 'bg-blue-900/50 text-blue-300 border-blue-700/50' : 'bg-blue-100 text-blue-700 border-blue-200',
      };
      return roles[this.role] || (this.isDarkMode ? 'bg-gray-700 text-gray-300 border-gray-600' : 'bg-gray-100 text-gray-700 border-gray-200');
    },

    // -------------------- 導航 --------------------
    goBack() {
      window.location.href = './../dashboard.html';
    },

    viewIncomplete() {
      const params = new URLSearchParams({
        name: this.websiteData.name,
        id: this.websiteData.id,
        percentage: this.websiteData.incompletePercentage
      });
      window.location.href = `./incomplete_tasks.html?${params.toString()}`;
    },

    // -------------------- 數據載入 --------------------
    loadWebsiteData() {
      try {
        const data = localStorage.getItem('currentWebsiteData');
        if (data) {
          this.websiteData = JSON.parse(data);
          
          // 確保數據格式正確
          if (!Array.isArray(this.websiteData.completedTasks)) {
            this.websiteData.completedTasks = [];
          }
          if (!Array.isArray(this.websiteData.incompleteTasks)) {
            this.websiteData.incompleteTasks = [];
          }
          
          this.recalculateProgress();
        }
      } catch (error) {
        console.error('載入資料時發生錯誤:', error);
      } finally {
        this.loading = false;
      }
    },

    // -------------------- 任務管理：新增 --------------------
    openAddTaskModal() {
      this.isEditMode = false;
      this.currentTask = {
        title: '',
        description: '',
        completedDate: new Date().toISOString().split('T')[0].replace(/-/g, '/'),
        completedBy: this.username
      };
      this.showTaskModal = true;
    },

    // -------------------- 任務管理：編輯 --------------------
    openEditTaskModal(task, index) {
      this.isEditMode = true;
      this.editingIndex = index;
      this.currentTask = { ...task };
      this.showTaskModal = true;
    },

    // -------------------- 任務管理：關閉模態框 --------------------
    closeTaskModal() {
      this.showTaskModal = false;
      this.isEditMode = false;
      this.editingIndex = null;
      this.currentTask = {
        title: '',
        description: '',
        completedDate: '',
        completedBy: ''
      };
    },

    // -------------------- 任務管理：保存 --------------------
    async saveTask() {
      if (!this.currentTask.title || !this.currentTask.description) {
        alert('請填寫任務標題和描述');
        return;
      }
      
      if (this.currentTask.completedDate && !/^\d{4}\/\d{2}\/\d{2}$/.test(this.currentTask.completedDate)) {
        alert('日期格式錯誤!請使用 YYYY/MM/DD 格式');
        return;
      }
      
      if (this.isEditMode) {
        this.websiteData.completedTasks[this.editingIndex] = { ...this.currentTask };
      } else {
        this.websiteData.completedTasks.push({ ...this.currentTask });
      }
      
      this.recalculateProgress();
      localStorage.setItem('currentWebsiteData', JSON.stringify(this.websiteData));
      await this.syncToBackend();
      this.closeTaskModal();
    },

    // -------------------- 任務管理：刪除 --------------------
    async deleteTask(index) {
      if (confirm('確定要刪除這個任務嗎?')) {
        this.websiteData.completedTasks.splice(index, 1);
        this.recalculateProgress();
        localStorage.setItem('currentWebsiteData', JSON.stringify(this.websiteData));
        await this.syncToBackend();
      }
    },

    // -------------------- 進度計算 --------------------
    recalculateProgress() {
      const completedCount = this.websiteData.completedTasks?.length || 0;
      const incompleteCount = this.websiteData.incompleteTasks?.length || 0;
      const totalCount = completedCount + incompleteCount;
      const incompletePercentage = totalCount === 0 ? 0 : Math.round((incompleteCount / totalCount) * 100);
      this.websiteData.percentage = incompletePercentage;
      this.websiteData.incompletePercentage = incompletePercentage;
    },

    // -------------------- 後端同步 --------------------
    async syncToBackend() {
      try {
        const response = await fetch(`http://127.0.0.1:5000/api/websites/${this.websiteData.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            website: this.websiteData,
            username: this.userId  // 使用工號而不是姓名
          })
        });
        
        const result = await response.json();
        
        if (!result.success) {
          console.error('❌ 同步失敗:', result.message);
          alert('資料同步失敗,請稍後再試');
        }
      } catch (error) {
        console.error('❌ 同步到後端時發生錯誤:', error);
        alert('無法連接到伺服器,資料僅保存在本地');
      }
    }
  }
});

app.mount('#app');