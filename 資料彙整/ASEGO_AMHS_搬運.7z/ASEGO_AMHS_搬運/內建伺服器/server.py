from loguru import logger
import os
import pymysql
from sqlalchemy import create_engine
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from waitress import serve

# 建立 log 資料夾
log_folder = r"D:\Data\4000API_ASEGO_message_log"
os.makedirs(log_folder, exist_ok=True)

# 設定 log 輸出與格式
log_file_path = os.path.join(log_folder, "api_{time:YYYY-MM-DD}.log")

logger.add(
    log_file_path,
    rotation="00:00",          # 每天凌晨切分
    retention="7 days",        # 保留 7 天
    encoding="utf-8",
    format="{time:YYYY-MM-DD HH:mm} | {level} | {message}",
    enqueue=True
)

logger.info("🚀 ASEGO API 伺服器啟動中...")

app = Flask(__name__)
CORS(app)

db_config = {
    'host': '10.11.104.247',
    'port': 3306,
    'user': 'A3CIM',
    'password': 'A3CIM',
    'database': 'error_rate_db',
    'charset': 'utf8mb4'
}


# 查找資料庫
engine = create_engine(
    f"mysql+pymysql://{db_config['user']}:{db_config['password']}@"
    f"{db_config['host']}:{db_config['port']}/{db_config['database']}?charset={db_config['charset']}",
    pool_recycle=1800,  # 每 1800 秒 (30 分鐘) 回收連線，防止 MySQL timeout
    pool_pre_ping=True  # 啟用 ping 檢查，避免使用壞掉的連線
)

@app.route('/upload_message', methods=['POST'])
def upload_message():
    data = request.get_json()

    if not data or 'message' not in data:
        logger.warning("缺少 message 欄位")
        return jsonify({'status': 'error', 'message': 'Missing "message" field'}), 400

    try:
        df = pd.DataFrame([{'message': data['message']}])
        df.to_sql('asego_water_level_alarm_messages', con=engine, if_exists='append', index=False)

        logger.info(f"收到訊息並已儲存：{data['message']}")
        return jsonify({'status': 'success', 'message': 'Message stored successfully'}), 200
    except Exception as e:
        logger.error(f"寫入失敗：{e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    # app.run()
    serve(app, host='10.11.99.84', port=8097, threads=100)