from loguru import logger
import os
import pymysql
from sqlalchemy import create_engine
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from waitress import serve
import pandas as pd


db_config = {
    'host': '10.11.104.247',
    'port': 3306,
    'user': 'A3CIM',
    'password': 'A3CIM',
    'database': 'error_rate_db',
    'charset': 'utf8mb4'
}


# 查找資料庫
engine = create_engine(
    f"mysql+pymysql://{db_config['user']}:{db_config['password']}@"
    f"{db_config['host']}:{db_config['port']}/{db_config['database']}?charset={db_config['charset']}",
    pool_recycle=1800,  # 每 1800 秒 (30 分鐘) 回收連線，防止 MySQL timeout
    pool_pre_ping=True  # 啟用 ping 檢查，避免使用壞掉的連線
)


df = pd.read_sql("SELECT * FROM asego_water_level_alarm_messages", engine)
# 檢查欄位是否存在
if 'message' in df.columns:
    df = df[df['message'].str.contains('K22', na=False)]
    df.to_csv("K22_data.csv", encoding="utf-8-sig")
else:
    print("⚠️ 資料表中找不到 'message' 欄位")

# df.to_csv("K22_data.csv", encoding="utf-8-sig")