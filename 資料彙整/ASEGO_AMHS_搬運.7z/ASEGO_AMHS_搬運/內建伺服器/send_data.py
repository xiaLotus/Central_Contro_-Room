import requests

url = 'http://10.11.99.84:8097/upload_message'

payload = {
    "message": "[K11-8F-4110 出料流道]<br>位置已達280分鐘未有貨批出料，請人員確認!"
}

try:
    response = requests.post(url, json=payload)
    print("Status Code:", response.status_code)
    print("Response:", response.json())
except Exception as e:
    print("Error sending request:", e)