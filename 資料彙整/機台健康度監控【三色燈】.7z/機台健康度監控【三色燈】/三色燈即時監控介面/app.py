from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from loguru import logger
import os
import threading
import json
import time

app = Flask(__name__)
CORS(app)

# 日誌初始化
log_folder = r"D:\Data\machine_monitoring_log"
os.makedirs(log_folder, exist_ok=True)
logger.add(
    os.path.join(log_folder, "machine_monitoring_log_{time:YYYY-MM-DD}.log"),
    rotation="00:00", retention="7 days", encoding="utf-8",
    format="{time:YYYY-MM-DD HH:mm} | {level} | {message}", enqueue=True
)
logger.info("🚀 機台健康度監控 伺服器啟動中...")

# 全域快取與鎖
current_data = []
data_lock = threading.Lock()


@app.route("/api/machine-status", methods=["POST"])
def receive_status():
    data = request.get_json()
    required_fields = ["building", "floor", "station", "status", "source_type"]

    if not all(field in data for field in required_fields):
        logger.warning(f"❌ 欄位缺失：{data}")
        return jsonify({"error": "缺少必要欄位"}), 400

    with data_lock:
        data["timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")

        # 找出該設備是否已存在
        existing_index = next((
            i for i, item in enumerate(current_data)
            if item["building"] == data["building"]
            and item["floor"] == data["floor"]
            and item["station"] == data["station"]
            and item["source_type"] == data["source_type"]
        ), None)

        if data["status"] == "ALARM":
            if existing_index is not None:
                current_data[existing_index] = data  
            else:
                current_data.append(data)
        else:
            if existing_index is not None:
                current_data.pop(existing_index) 

        if len(current_data) > 100:
            current_data.pop(0)


    logger.info(f"✅ 寫入成功（去重後）：{data}")
    return jsonify({"message": "資料已接收"}), 200


@app.route("/stream")
def stream():
    def event_stream():
        last = ""
        while True:
            time.sleep(1)
            with data_lock:
                payload = json.dumps(current_data)
            if payload != last:
                last = payload
                yield f"data: {payload}\n\n"
    return Response(event_stream(), content_type="text/event-stream")

if __name__ == '__main__':
    app.run(debug=True, threaded=True)
