const app = Vue.createApp({
  data() {
    return {
      dataList: []
    };
  },
  mounted() {
    const source = new EventSource("http://127.0.0.1:5000/stream");
    source.onmessage = (e) => {
      this.dataList = JSON.parse(e.data);
      console.log(this.dataList)
    };
  }
});

app.mount("#app");