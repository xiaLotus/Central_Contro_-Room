import json
import os
import sys
import time
import threading
import requests
from pymodbus.client.sync import ModbusTcpClient
from datetime import datetime
import logging
from logging.handlers import TimedRotatingFileHandler


ip = '172.21.45.227'
port = 502
client = ModbusTcpClient(ip, port)


conn = client.connect()


while True:
    try:
        result = client.read_discrete_inputs(0, 12, unit=1)
        if result.isError():
            print("Modbus 讀取失敗")
            time.sleep(1)
            continue
        di_array = [0 if bit else 1 for bit in result.bits] # type: ignore
        print(di_array)

    except Exception as e:
        time.sleep(5)
