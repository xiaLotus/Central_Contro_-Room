import json
import os
import re
import time
import subprocess
from datetime import datetime, timedelta
from loguru import logger
from pymodbus.client.sync import ModbusTcpClient

MACHINE_ID = "3390-car-L"
LOG_PATH = r"D:\ADAM6050_Heath_data\ADAM\dist\Log\172_22_103_229\log_172_22_103_229.log"
EXE_NAME = "ADAM_6050.exe"
EXE_PATH = r"D:\ADAM6050_Heath_data\ADAM\dist\ADAM_6050.exe" 
MACHINE_CONFIG = r"\\20220530-W03\Data\Adam3LED\K22-8F-3LED.json"
TIMEOUT_MINUTES = 30
RESTART_LOG_PATH = os.path.join(os.path.dirname(LOG_PATH), "reset/restart.log")

logger.add(RESTART_LOG_PATH, rotation="00:00", retention="30 days", encoding="utf-8",
           format="[{time:YYYY-MM-DD HH:mm:ss}] {message}")

LOG_TIME_PATTERN = re.compile(rf"\[(.*?)\] {re.escape(MACHINE_ID)} 狀態切換為 (\w+)")

def load_machine_by_id(machine_id):
    if not os.path.exists(MACHINE_CONFIG):
        logger.error(f"❌ 找不到設定檔：{MACHINE_CONFIG}")
        return None
    with open(MACHINE_CONFIG, "r", encoding="utf-8") as f:
        machines = json.load(f)
    return next((m for m in machines if m["MachineID"] == machine_id), None)

# def get_last_status_change_time(log_path):
#     if not os.path.exists(log_path):
#         logger.info(f"❌ 找不到 log 檔案：{log_path}")
#         logger.error(f"{MACHINE_ID} ❌ 找不到狀態 log：{log_path}")
#         return None

#     with open(log_path, "r", encoding="utf-8") as f:
#         lines = f.readlines()

#     for line in reversed(lines):
#         match = LOG_TIME_PATTERN.search(line)
#         if match:
#             return datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S,%f")
#     return None

def get_last_log_status_and_time(log_path):
    if not os.path.exists(log_path):
        logger.error(f"{MACHINE_ID} ❌ 找不到狀態 log：{log_path}")
        return None, None

    with open(log_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line in reversed(lines):
        match = LOG_TIME_PATTERN.search(line)
        if match:
            log_time = datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S,%f")
            state = match.group(2)
            return log_time, state
    return None, None

def get_current_state(machine):
    ip = machine["IP"]
    port = machine.get("Port", 502)
    di_map = machine.get("DI_Map", {"RED": 0, "YELLOW": 1, "GREEN": 2})

    try:
        with ModbusTcpClient(ip, port=port, timeout=2) as client:
            if not client.connect():
                logger.warning(f"{MACHINE_ID} ❌ Modbus 無法連線")
                return None

            result = client.read_discrete_inputs(0, 12, unit=1)
            if result.isError():
                logger.warning(f"{MACHINE_ID} ❌ Modbus 讀取失敗")
                return None

            di_array = [1 if bit else 0 for bit in result.bits] # type: ignore

            def safe_get(index):
                return di_array[index] if index < len(di_array) else 0

            red = safe_get(di_map.get("RED", 0))
            yellow = safe_get(di_map.get("YELLOW", 1))
            green = safe_get(di_map.get("GREEN", 2))
            blue = safe_get(di_map.get("BLUE", 99))  # optional

            state_tuple = (red, yellow, green, blue)
            return "BUSY" if state_tuple == (0, 0, 1, 0) else "ALARM"

    except Exception as e:
        logger.error(f"{MACHINE_ID} ❌ Modbus 發生錯誤：{e}")
        return None



def restart_exe():
    logger.info(f"🛑 關閉 {EXE_NAME}...")
    logger.warning(f"{MACHINE_ID} 狀態超過 {TIMEOUT_MINUTES} 分鐘未變更，自動關閉 {EXE_NAME}")
    subprocess.run(["taskkill", "/f", "/im", EXE_NAME], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    logger.info(f"🚀 重新啟動 {EXE_NAME}...")
    subprocess.Popen(f'start "ADAM_6050" "{EXE_PATH}"', shell=True)
    logger.success(f"{MACHINE_ID} 已重新啟動 {EXE_NAME}")

# last_change = get_last_status_change_time(LOG_PATH)
# now = datetime.now()

# if last_change:
#     diff = now - last_change
#     logger.info(f"⏱️ 最後變更：{last_change}, 距今 {diff.total_seconds()//60:.1f} 分鐘")

#     if diff > timedelta(minutes=TIMEOUT_MINUTES):
#         logger.info(f"⚠️ 超過 {TIMEOUT_MINUTES} 分鐘未更新狀態，偵測是否重啟")
#         try:
#             pass
#         except Exception as e:
#             print(e)
#         restart_exe()
#     else:
#         logger.info(f"✅ 狀態變更正常，無需重啟")
# else:
#     logger.info("❌ 無法取得狀態切換時間")
#     time.sleep(1)  # 給 logger 時間寫檔
#     logger.error(f"{MACHINE_ID} ❌ 無狀態變更紀錄，無法判斷")

# === Main Flow ===
machine = load_machine_by_id(MACHINE_ID)
if not machine:
    logger.error(f"{MACHINE_ID} ❌ 找不到對應設定，結束")
    exit(1)

log_time, last_state = get_last_log_status_and_time(LOG_PATH)
now = datetime.now()

if log_time:
    diff = now - log_time
    logger.info(f"⏱️ 最後變更：{log_time}, 距今 {diff.total_seconds()//60:.1f} 分鐘")

    current_state = get_current_state(machine)
    if current_state:
        if current_state == last_state:
            logger.info(f"✅ 即時狀態 [{current_state}] 與 log 一致，不執行重啟")
        elif diff > timedelta(minutes=TIMEOUT_MINUTES):
            logger.warning(f"⚠️ 狀態不同，且超過 {TIMEOUT_MINUTES} 分鐘未變更，執行重啟")
            restart_exe()
        else:
            logger.info(f"⚠️ 狀態不同，但尚未超過 {TIMEOUT_MINUTES} 分鐘，略過")
    else:
        logger.error(f"{MACHINE_ID} ❌ 無法取得目前設備狀態")
else:
    logger.error(f"{MACHINE_ID} ❌ 無狀態變更紀錄，無法判斷")