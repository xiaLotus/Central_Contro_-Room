import json
import os
import sys
import time
import threading
import requests
from pymodbus.client.sync import ModbusTcpClient
from datetime import datetime
import logging
from logging.handlers import TimedRotatingFileHandler

API_URL = "http://lba3cim:8081/AmhsMSChangeApi/api/post/amscsetdata"
HEADERS = {'Content-Type': 'application/json'}
MACHINE_CONFIG = r"\\20220530-W03\Data\Adam3LED\K22-8F-3LED.json"
TV_url = 'http://10.11.99.84:8105/api/machine-status'

# PID_PATH = r"D:\ADAM6050_Heath_data\ADAM\app.pid"
# with open(PID_PATH, "w") as f:
#     f.write(str(os.getpid()))


stop_event = threading.Event()
threads = []
running_machines = {}

device_loggers = {}

def timestamp():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")


def get_base_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.abspath(__file__))

def get_device_logger(ip):
    if ip in device_loggers:
        return device_loggers[ip]

    base_dir = get_base_dir()
    # log_dir = os.path.join(base_dir, "Log")
    log_dir = os.path.join(base_dir, "Log", ip.replace(".", "_"))  # 👈 每個 IP 建資料夾
    os.makedirs(log_dir, exist_ok=True)

    log_name = f"log_{ip.replace('.', '_')}"
    log_path = os.path.join(log_dir, f"{log_name}.log")

    handler = TimedRotatingFileHandler(
        log_path, when="midnight", interval=1, backupCount=30, encoding="utf-8"
    )
    handler.suffix = "%Y-%m-%d"
    formatter = logging.Formatter("[%(asctime)s] %(message)s")
    handler.setFormatter(formatter)

    # logger = logging.getLogger(log_name)
    logger = logging.getLogger(f"log_{ip}")
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
    logger.propagate = False

    device_loggers[ip] = logger
    return logger

# def get_device_logger(ip):
#     if ip in device_loggers:
#         return device_loggers[ip]

#     os.makedirs(r"D:\ADAM6050_Heath_data\3_LED\dist\Log", exist_ok=True)
#     log_name = f"log_{ip.replace('.', '_')}"
#     log_path = os.path.join("Log", f"{log_name}.log")

#     handler = TimedRotatingFileHandler(
#         log_path, when="midnight", interval=1, backupCount=30, encoding="utf-8"
#     )
#     handler.suffix = "%Y-%m-%d"
#     formatter = logging.Formatter("[%(asctime)s] %(message)s")
#     handler.setFormatter(formatter)

#     logger = logging.getLogger(log_name)
#     logger.setLevel(logging.INFO)
#     logger.addHandler(handler)
#     logger.propagate = False

#     device_loggers[ip] = logger
#     return logger

def load_machines():
    with open(MACHINE_CONFIG, "r", encoding='utf-8') as f:
        return json.load(f)

def write_log(ip, machine_id, state):
    logger = get_device_logger(ip)
    logger.info(f"{machine_id} 狀態切換為 {state}")

def log_reconnect(ip, machine_id, success):
    logger = get_device_logger(ip)
    msg = f"{machine_id} " + ("✅ 連線成功" if success else "🔁 正在重新嘗試連線中...")
    logger.info(msg)

def post_state(data_template, state):
    payload = data_template.copy()
    payload["State"] = state
    try:
        response = requests.post(API_URL, json=payload, headers=HEADERS, verify=False)
        data = {
            "building": "K22",
            "floor": "8F",
            "station": f"{payload['MachineID']}",
            "status": f"{state}",
            "source_type": "ADAM-6050"
        }
        TV_response = requests.post(TV_url, json=data)
        if response.status_code == 200:
            print(f"{timestamp()} [INFO] 上拋成功: {payload['MachineID']} - {state}")
            print("Status Code:", TV_response.status_code)
            print("Response:", TV_response.json())
        else:
            print(f"{timestamp()} [ERROR] 上拋失敗: {payload['MachineID']} Status Code: {response.status_code}")
    except Exception as e:
        print(f"{timestamp()} [ERROR] 發送錯誤: {payload['MachineID']} - {e}")



def poll_machine(machine, stop_flag):
    ip = machine["IP"]
    port = machine.get("Port", 502)
    machine_id = machine["MachineID"]

    print(f"{timestamp()} [INFO] 開始監控設備 {machine_id} ({ip}:{port})")
    logger = get_device_logger(ip)

    count = 0
    last_state = None
    data_template = {
        "Plant": machine["Plant"],
        "Site": machine["Site"],
        "MachineID": machine_id
    }

    while not stop_event.is_set() and not stop_flag.is_set():
        try:
            with ModbusTcpClient(ip, port=port, timeout=2) as client:
                if not client.connect():
                    log_reconnect(ip, machine_id, success=False)
                    raise ConnectionError(f"{ip} 無法連線")

                log_reconnect(ip, machine_id, success=True)

                while not stop_event.is_set() and not stop_flag.is_set():
                    result = client.read_discrete_inputs(0, 12, unit=1)
                    if result.isError():
                        raise IOError("Modbus 讀取失敗")
                    
                    def safe_get_di(di_array, index):
                        return di_array[index] if index < len(di_array) else 0
                    
                    di_array = [1 if bit else 0 for bit in result.bits] # type: ignore

                    # 取得 DI_Map 中的紅黃綠燈腳位編號
                    di_map = machine.get("DI_Map", {"RED": 0, "YELLOW": 1, "GREEN": 2})
                    # red = di_array[di_map.get("RED", 0)]
                    # yellow = di_array[di_map.get("YELLOW", 1)]
                    # green = di_array[di_map.get("GREEN", 2)]
                    # blue = di_array[di_map.get("BLUE", 3)]
                    red = safe_get_di(di_array, di_map.get("RED", 0))
                    yellow = safe_get_di(di_array, di_map.get("YELLOW", 1))
                    green = safe_get_di(di_array, di_map.get("GREEN", 2))
                    blue = safe_get_di(di_array, di_map.get("BLUE", 99))  # 如果沒有定義藍燈，就用 index 99，safe_get_di 會自動回傳 0

                    
                    state_tuple = (red, yellow, green, blue)

                    # if (di_array[0] == 0 and di_array[1] == 0 and di_array[2] == 1):
                    #     state = "ALARM" if count < 3 else "BUSY"
                    #     count += 1
                    if state_tuple == (0, 0, 1, 0):
                        state = "ALARM" if count < 3 else "BUSY"
                        count += 1
                    else:
                        state = "ALARM"
                        count = 0


                    if state != last_state:
                        post_state(data_template, state)
                        write_log(ip, machine_id, state)
                        last_state = state
                        
                    now = datetime.now()
                    if now.strftime("%H:%M") in ["07:30", "19:30"] and now.second == 0:
                        post_state(data_template, state)
                        logger.info(f"[定時上拋] {machine_id} 狀態為 {state}")

                    time.sleep(1)

        except Exception as e:
            log_reconnect(ip, machine_id, success=False)
            logger.error(f"{machine_id} 通訊錯誤，5 秒後重試：{e}")
            print(f"{timestamp()} [ERROR] {machine_id} 通訊錯誤，將於 5 秒後重試：{e}")
            time.sleep(5)

def monitor_new_devices():
    while not stop_event.is_set():
        try:
            machines = load_machines()
            current_ips = set(m["IP"] for m in machines)
            new_ips = current_ips - running_machines.keys()
            removed_ips = running_machines.keys() - current_ips

            for m in machines:
                ip = m["IP"]
                if ip in new_ips:
                    print(f"{timestamp()} [INFO] 新設備 {ip}，啟動監控...")
                    stop_flag = threading.Event()
                    t = threading.Thread(target=poll_machine, args=(m, stop_flag))
                    t.start()
                    running_machines[ip] = (t, stop_flag)

            for ip in removed_ips:
                print(f"{timestamp()} [INFO] 設備 {ip} 已被移除，停止監控")
                _, stop_flag = running_machines[ip]
                stop_flag.set()
                running_machines[ip][0].join()
                del running_machines[ip]

        except Exception as e:
            print(f"{timestamp()} [ERROR] 載入設備失敗: {e}")
        time.sleep(15)

def main():
    if not os.path.exists(MACHINE_CONFIG):
        print(f"[ERROR] 找不到 JSON 設定檔：{MACHINE_CONFIG}")
        exit(1)

    monitor_thread = threading.Thread(target=monitor_new_devices)
    monitor_thread.start()
    threads.append(monitor_thread)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{timestamp()} [INFO] 偵測中斷，正在停止所有設備...")
        stop_event.set()
        for t in threads:
            t.join()
        print(f"{timestamp()} [INFO] 所有設備已停止")

if __name__ == "__main__":
    main()


