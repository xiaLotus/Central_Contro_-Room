import requests

url = 'http://10.11.99.84:8105/api/machine-status'


data = {
    "building": "K22",
    "floor": "8F",
    "station": "3390-流道台車-TEST",
    "status": "ALARM",
    "source_type": "ADAM-6050"
}
try:
    response = requests.post(url, json=data)
    print("Status Code:", response.status_code)
    print("Response:", response.json())
except Exception as e:
    print("Error sending request:", e)